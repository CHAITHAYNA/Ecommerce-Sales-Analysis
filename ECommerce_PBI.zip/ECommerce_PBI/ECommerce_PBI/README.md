# E-Commerce Analytics - Power BI Project

## Open it
1. Power BI Desktop -> File > Open report > Browse, pick `ECommerce_Analytics.pbip`.
   (If it won't open: File > Options > Preview features > enable "Power BI Project (.pbip) save option" and "Store reports using enhanced metadata format (PBIR)", restart.)
2. Click **Refresh** (Home ribbon) once. The four CSVs are embedded in the model's queries, so no file paths are needed.
3. **File > Save as** and choose `.pbix` if you want a single file.

## Model
Star schema: Customers 1-* Orders 1-* OrderItems *-1 Products, plus DimDate 1-* Orders (order_date).
OrderItems -> Orders is bi-directional so Category/Product slicers also filter order and customer counts.
Measures live in `_Measures`, grouped in folders: Sales, Orders, Customers, Products & Inventory.

## Pages
1. Executive Overview  2. Product Performance  3. Customer Insights  4. Orders & Payments

## Definitions
- Net Revenue = Delivered + Pending orders (Cancelled and Returned excluded). Gross Sales = every line. Lost Revenue = Cancelled + Returned.
- Rates (cancellation, return, delivery) use all orders as the denominator.
- Line Total = quantity x unit_price (unit_price always equals the product list price in this data).

## Data notes
- 26 of 500 orders have no line items; they count in Total Orders but not in Net Orders / revenue.
- Orders run 12 May 2025 - 12 May 2026, so the first and last months are partial.
- Data is clean: no nulls, duplicates or orphan keys.

## Refreshing with new data
Transform data > pick a table > replace the Source step with `Csv.Document(File.Contents("C:\path\file.csv"), [Delimiter=",", Encoding=65001])`.
